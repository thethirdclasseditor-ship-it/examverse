/* ==========================================================================
   ExamVerse — Supabase Cloud Connector (js/supabase-client.js)
   Drop-in bridge between LocalStorage and Supabase PostgreSQL + Auth
   ========================================================================== */

(function () {
  var SUPABASE_CONFIG = {
    url: 'https://YOUR_PROJECT_ID.supabase.co',
    anonKey: 'YOUR_SUPABASE_ANON_PUBLIC_KEY',
    enabled: false /* Set to true after pasting your Supabase URL & Anon Key */
  };

  var CloudService = {
    isConfigured: function () {
      return Boolean(
        SUPABASE_CONFIG.enabled &&
        SUPABASE_CONFIG.url &&
        SUPABASE_CONFIG.url.indexOf('YOUR_PROJECT_ID') === -1
      );
    },

    /* Fetch Paginated MCQs by Chapter (Supports 100,000+ rows without loading all at once) */
    fetchChapterMcqs: async function (subjectId, chapterId, limit, offset) {
      if (!this.isConfigured()) {
        /* Fallback to local bundled dataset */
        return window.EXAMVERSE_DATA.questions.filter(function (q) {
          return (!subjectId || q.subjectId === subjectId) && (!chapterId || q.chapterId === chapterId);
        });
      }

      var pageLimit = limit || 25;
      var pageOffset = offset || 0;
      var endpoint =
        SUPABASE_CONFIG.url +
        '/rest/v1/questions_mcq?select=*&status=eq.published' +
        (subjectId && subjectId !== 'all' ? '&subject_id=eq.' + encodeURIComponent(subjectId) : '') +
        (chapterId && chapterId !== 'all' ? '&chapter_id=eq.' + encodeURIComponent(chapterId) : '') +
        '&limit=' + pageLimit +
        '&offset=' + pageOffset;

      var response = await window.fetch(endpoint, {
        headers: {
          apikey: SUPABASE_CONFIG.anonKey,
          Authorization: 'Bearer ' + SUPABASE_CONFIG.anonKey
        }
      });
      if (!response.ok) {
        throw new Error('Failed to fetch MCQs from Supabase');
      }
      return await response.json();
    }
  };

  window.ExamVerseCloud = CloudService;
})();
