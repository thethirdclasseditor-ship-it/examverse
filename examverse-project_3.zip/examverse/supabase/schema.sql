-- ============================================================================
-- ExamVerse — Production PostgreSQL Schema for Supabase (supabase/schema.sql)
-- Engineered to scale to 500,000+ MCQs & Creative Questions (CQs)
-- ============================================================================

-- 1. Exam Categories (SSC, HSC, University, Medical, Engineering, BCS, Bank, Gov, GK)
CREATE TABLE IF NOT EXISTS public.exam_categories (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  name_bn TEXT NOT NULL,
  full_title TEXT NOT NULL,
  badge TEXT,
  description TEXT,
  icon_type TEXT DEFAULT 'book',
  sort_order INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Subjects (Physics, Chemistry, Higher Math, Biology, English, Bangla, GK, ICT, etc.)
CREATE TABLE IF NOT EXISTS public.subjects (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  name_bn TEXT NOT NULL,
  paper TEXT DEFAULT '1st & 2nd Paper',
  icon TEXT DEFAULT 'atom',
  accent TEXT DEFAULT 'indigo',
  sort_order INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 3. Category <-> Subject Mapping (Many-to-Many)
CREATE TABLE IF NOT EXISTS public.category_subjects (
  category_id TEXT REFERENCES public.exam_categories(id) ON DELETE CASCADE,
  subject_id TEXT REFERENCES public.subjects(id) ON DELETE CASCADE,
  PRIMARY KEY (category_id, subject_id)
);

-- 4. Chapters (Per Subject)
CREATE TABLE IF NOT EXISTS public.chapters (
  id TEXT PRIMARY KEY,
  subject_id TEXT NOT NULL REFERENCES public.subjects(id) ON DELETE CASCADE,
  chapter_number INT DEFAULT 1,
  title TEXT NOT NULL,
  title_bn TEXT NOT NULL,
  difficulty TEXT DEFAULT 'Medium' CHECK (difficulty IN ('Easy', 'Medium', 'Hard')),
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chapters_subject ON public.chapters(subject_id);

-- 5. MCQ Questions Bank (Supports 500,000+ rows with B-Tree & GIN Indexes)
CREATE TABLE IF NOT EXISTS public.questions_mcq (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id TEXT NOT NULL REFERENCES public.subjects(id) ON DELETE RESTRICT,
  chapter_id TEXT NOT NULL REFERENCES public.chapters(id) ON DELETE RESTRICT,
  category_tags TEXT[] DEFAULT '{}',      -- e.g. ARRAY['hsc', 'uni', 'eng']
  board_or_exam_tag TEXT,                 -- e.g. 'BUET 23-24', 'Dhaka Board 2024', '46th BCS'
  exam_year INT,                          -- e.g. 2024
  difficulty TEXT DEFAULT 'Medium' CHECK (difficulty IN ('Easy', 'Medium', 'Hard')),
  question_en TEXT,
  question_bn TEXT NOT NULL,
  stem_image_url TEXT,                    -- Optional Cloudflare R2 image URL
  options JSONB NOT NULL,                 -- ["Option A", "Option B", "Option C", "Option D"]
  correct_index SMALLINT NOT NULL CHECK (correct_index BETWEEN 0 AND 3),
  explanation_en TEXT,
  explanation_bn TEXT,
  has_latex BOOLEAN DEFAULT FALSE,
  status TEXT DEFAULT 'published' CHECK (status IN ('draft', 'published', 'archived')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_mcq_subject_chapter ON public.questions_mcq(subject_id, chapter_id);
CREATE INDEX IF NOT EXISTS idx_mcq_categories_gin ON public.questions_mcq USING GIN (category_tags);
CREATE INDEX IF NOT EXISTS idx_mcq_difficulty ON public.questions_mcq(difficulty);

-- 6. Creative Questions / সৃজনশীল প্রশ্ন (CQ Bank: উদ্দীপক + ক, খ, গ, ঘ)
CREATE TABLE IF NOT EXISTS public.questions_cq (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  subject_id TEXT NOT NULL REFERENCES public.subjects(id) ON DELETE RESTRICT,
  chapter_id TEXT NOT NULL REFERENCES public.chapters(id) ON DELETE RESTRICT,
  category_tags TEXT[] DEFAULT '{}',
  board_or_exam_tag TEXT,                 -- e.g. 'Rajshahi Board 2024'
  stem_passage_bn TEXT NOT NULL,          -- উদ্দীপক (Stem text)
  stem_image_url TEXT,                    -- উদ্দীপকের চিত্র (Cloudflare R2 URL)
  q_ka TEXT NOT NULL,                     -- ক) জ্ঞানমূলক প্রশ্ন (১ নম্বর)
  ans_ka TEXT NOT NULL,
  q_kha TEXT NOT NULL,                    -- খ) অনুধাবনমূলক প্রশ্ন (২ নম্বর)
  ans_kha TEXT NOT NULL,
  q_ga TEXT NOT NULL,                     -- গ) প্রয়োগমূলক প্রশ্ন (৩ নম্বর)
  ans_ga TEXT NOT NULL,
  q_gha TEXT NOT NULL,                    -- ঘ) উচ্চতর দক্ষতামূলক প্রশ্ন (৪ নম্বর)
  ans_gha TEXT NOT NULL,
  status TEXT DEFAULT 'published',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_cq_subject_chapter ON public.questions_cq(subject_id, chapter_id);

-- 7. Student Profiles & Gamification State (Linked to Supabase Auth)
CREATE TABLE IF NOT EXISTS public.user_profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE,
  full_name TEXT,
  target_track TEXT DEFAULT 'University & Engineering Admission',
  level INT DEFAULT 1,
  xp INT DEFAULT 0,
  streak_days INT DEFAULT 0,
  last_study_date DATE,
  theme_pref TEXT DEFAULT 'light',
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 8. Row Level Security (RLS) Policies
ALTER TABLE public.exam_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions_mcq ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.questions_cq ENABLE ROW LEVEL SECURITY;

-- Public Read Access for Published Educational Content
CREATE POLICY "Public read categories" ON public.exam_categories FOR SELECT USING (true);
CREATE POLICY "Public read subjects" ON public.subjects FOR SELECT USING (true);
CREATE POLICY "Public read chapters" ON public.chapters FOR SELECT USING (true);
CREATE POLICY "Public read published MCQs" ON public.questions_mcq FOR SELECT USING (status = 'published');
CREATE POLICY "Public read published CQs" ON public.questions_cq FOR SELECT USING (status = 'published');
